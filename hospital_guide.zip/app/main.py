from fastapi import FastAPI
from app.api.endpoints import health  # 导入我们即将编写的健康检查路由
from app.api.endpoints import auth,health, map, robots 
from app.api.endpoints import navigation,speech

# 创建FastAPI应用实例
app = FastAPI(
    title="医院导引系统后端API",
    description="为APP和硬件小车提供服务的后端系统",
    version="0.1.0"
)
from fastapi.middleware.cors import CORSMiddleware

# 允许的前端地址
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 将健康检查路由包含到应用中，并为其指定前缀和标签
app.include_router(health.router, prefix="/api/v1", tags=["健康检查"])
app.include_router(auth.router, prefix="/api/v1", tags=["用户认证"])
app.include_router(map.router, prefix="/api/v1", tags=["地图导航"])  # 新增
app.include_router(robots.router, prefix="/api/v1", tags=["导引小车"])  # 新增
app.include_router(navigation.router, prefix="/api/v1/navigation", tags=["导航任务"])  # 新增
app.include_router(speech.router, prefix="/api/v1/speech", tags=["语音服务"])
# 一个最简单的根路径路由，用于快速验证服务是否存活
@app.get("/")
async def root():
    return {"message": "Server is alive and ready for Hospital Guide!"}